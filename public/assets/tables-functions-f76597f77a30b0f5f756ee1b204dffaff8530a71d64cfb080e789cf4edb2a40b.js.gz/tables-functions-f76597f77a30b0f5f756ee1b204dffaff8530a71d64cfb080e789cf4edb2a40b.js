
$(document).ready(function () {
    console.log('Tables!');

    $('.Collage').collagePlus();

});
